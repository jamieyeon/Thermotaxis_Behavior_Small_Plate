function y=modellin(p,x);

y=p(1)+p(2)*x;