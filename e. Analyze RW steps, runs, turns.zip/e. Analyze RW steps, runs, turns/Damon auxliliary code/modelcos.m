function y=modelcos(p,x);

% model of cosine, expected in various angular fits i'm doing

y=p(1)+p(2)*cos(x);