function y=modelconst(p,x)

y=p(1)*ones(size(x));