function y=modellinear(p,x);

y=p(1)+p(2)*x;