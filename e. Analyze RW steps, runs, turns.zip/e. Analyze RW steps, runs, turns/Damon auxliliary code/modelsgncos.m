function y=modelsgncos(p,x)

y=p(1)+p(2)*(cos(x)>=0);